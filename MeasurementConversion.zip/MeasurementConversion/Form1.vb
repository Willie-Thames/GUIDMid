﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim notA As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*(),./<>?;{}_-'"
        Dim l As String
        For x As Integer = 0 To TB1.Text.Length - 1
            l = TB1.Text.Substring(x, 1)
            If notA.Contains(l) Then
                MsgBox("Please enter a positive value and choose your conversion")
            End If
        Next
        If I2M.Checked Then
            Dim given As Decimal
            given = TB1.Text
            Dim rec As Decimal
            rec = given / 39.3701
            Dim fStr As String
            fStr = given + " Inches is " + rec + " meters long"
            donetxt.Text = fStr
        End If
        If M2I.Checked Then
            Dim given As Decimal
            given = TB1.Text
            Dim rec As Decimal
            rec = given * 39.3701
            Dim fStr As String
            fStr = given + " Meters is " + rec + " inches long"
            donetxt.Text = fStr
        End If
    End Sub

    Friend Shared Sub EnableVisualStyles()
        Throw New NotImplementedException()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TB1.Text = ""
        M2I.Checked = False
        I2M.Checked = True
        Dim unused = TB1.Focused()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

End Class