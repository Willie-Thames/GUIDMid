﻿Imports MeasurementConversion

Module Module1
    Sub Main()
        AppActivate(Form1)
    End Sub

    Private Sub AppActivate(form1 As Form1)
        Throw New NotImplementedException()
    End Sub
End Module
